const founders = [
  {
    _id: "639fc07e814e88c4fa33c0a8",
    idea: "639fa61f44ff002100705854",
    name: "haha",
    picture: "uploads\\1671413886032.png",
    __v: 0,
  },
];
export default founders;
