let users = [
  {
    _id: "639fb7692d575b0588e3eb76",
    first_name: "Ahmed",
    last_name: "Nabeel",
    profile: "uploads\\1671411561733.jpg",
    cnic: "31",
    phone: "212",
    is_entreprenure: false,
    email: "anmirza68@gmail.com",
    password: "$2a$10$O1WNJpOQT9ZLN41gEm1UG.f1X2d1nVEaXGHKvYy4an7ylOjxN6uvG",
    member_since: "2022-12-19T04:36:17.607+00:00",
    __v: 0,
  },
  {
    _id: "639fea41f9aa7165417719d2",
    first_name: "Ahmed",
    last_name: "Nabeel",
    profile: "uploads\\1671424577046.jpg",
    cnic: "31",
    phone: "212",
    is_entreprenure: false,
    email: "anmirza37@gmail.com",
    password: "$2a$10$AclsJSuASHuN3NXpwMxdL.CoFOFx4qnUyrcpHb2xhkAgnfGeeAgLO",
    member_since: "2022-12-19T04:36:17.607+00:00",
    __v: 0,
  },
];
export default users;
