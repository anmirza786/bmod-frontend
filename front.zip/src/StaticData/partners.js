let partners = [
  {
    _id: "639fc061814e88c4fa33c0a6",
    idea: "639fa61f44ff002100705854",
    name: "haha",
    picture: "uploads\\1671413857410.png",
    __v: 0,
  },
];
export default partners;
