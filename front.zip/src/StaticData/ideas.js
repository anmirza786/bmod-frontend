const ideas = [
  {
    _id: "639fa61f44ff002100705854",
    user: "639fb7692d575b0588e3eb76",
    name: "a",
    thumbnail: "uploads\\1671407132828.jpg",
    description:
      "3 Line Description Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae explicabo minima tempore aliquam eveniet",
    investment_percentage: 10,
    legal_documentation: "uploads\\1671407132830.pdf",
    required_investment: 20,
    video: "uploads\\1671407132831.mp4",
    is_approved: true,
  },
  {
    _id: "639fa79844ff002100705856",
    user: "639fb7692d575b0588e3eb76",
    name: "a",
    thumbnail: "uploads\\1671407508026.jpg",
    description:
      "3 Line Description Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae explicabo minima tempore aliquam eveniet",
    investment_percentage: 10,
    legal_documentation: "uploads\\1671407508028.pdf",
    required_investment: 20,
    video: "uploads\\1671407508028.mp4",
    is_approved: false,
  },
];
export default ideas;
