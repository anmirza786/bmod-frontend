const investors = [
  {
    _id: "639fbe59633c82b1b3b88cfa",
    user: "639fb7692d575b0588e3eb76",
    idea: "639fa61f44ff002100705854",
    invested: 10,
    __v: 0,
  },
];
export default investors;
