import React from "react";
import Overview from "./Components/Overview";

function AddGig(props) {
  return (
    <div className="container">
      <Overview />
    </div>
  );
}

export default AddGig;
