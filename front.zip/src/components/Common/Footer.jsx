import React from "react";

function Footer(props) {
  return (
    <footer style={{ padding: "1.5rem",background: "white" }}>
      <div className="content has-text-centered">
        <p>Copyright© BEMOD</p>
      </div>
    </footer>
  );
}

export default Footer;
